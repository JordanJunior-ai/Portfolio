import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { MessageCircle } from "lucide-react";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    projectType: "",
    message: "",
  });

  const { toast } = useToast();

  const contactMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await apiRequest("POST", "/api/contacts", data);
    },
    onSuccess: () => {
      toast({
        title: "Message sent successfully!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      setFormData({ name: "", email: "", projectType: "", message: "" });
    },
    onError: () => {
      toast({
        title: "Error sending message",
        description: "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.projectType || !formData.message) {
      toast({
        title: "Please fill in all fields",
        description: "All fields are required.",
        variant: "destructive",
      });
      return;
    }
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const contactInfo = [
    {
      icon: <MessageCircle className="text-[hsl(158,64%,52%)]" />,
      title: "Discord",
      value: "kirinonyt",
      bgColor: "bg-[hsl(158,64%,52%)]/20",
    },
  ];



  return (
    <section id="contact" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[hsl(217,91%,60%)]">Get In Touch</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[hsl(217,91%,60%)] to-[hsl(158,64%,52%)] mx-auto mb-4"></div>
          <p className="text-lg text-[hsl(215,20%,65%)]">Ready to create amazing UI experiences together?</p>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <Card className="bg-[hsl(210,40%,8%)]/50 border-[hsl(217,32%,17%)]">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold mb-6 text-[hsl(217,91%,60%)]">Send Message</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label htmlFor="name" className="text-[hsl(215,20%,65%)] mb-2">Name</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Your Name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      className="bg-[hsl(217,32%,17%)] border-[hsl(217,32%,17%)]/50 focus:border-[hsl(217,91%,60%)] text-white"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email" className="text-[hsl(215,20%,65%)] mb-2">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="bg-[hsl(217,32%,17%)] border-[hsl(217,32%,17%)]/50 focus:border-[hsl(217,91%,60%)] text-white"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="projectType" className="text-[hsl(215,20%,65%)] mb-2">Project Type</Label>
                    <Select value={formData.projectType} onValueChange={(value) => handleInputChange("projectType", value)}>
                      <SelectTrigger className="bg-[hsl(217,32%,17%)] border-[hsl(217,32%,17%)]/50 focus:border-[hsl(217,91%,60%)] text-white">
                        <SelectValue placeholder="Select project type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="shop-interface">Shop Interface</SelectItem>
                        <SelectItem value="game-hud">Game HUD</SelectItem>
                        <SelectItem value="menu-system">Menu System</SelectItem>
                        <SelectItem value="custom-ui">Custom UI</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="message" className="text-[hsl(215,20%,65%)] mb-2">Message</Label>
                    <Textarea
                      id="message"
                      rows={4}
                      placeholder="Tell me about your project..."
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      className="bg-[hsl(217,32%,17%)] border-[hsl(217,32%,17%)]/50 focus:border-[hsl(217,91%,60%)] text-white"
                    />
                  </div>
                  
                  <Button
                    type="submit"
                    disabled={contactMutation.isPending}
                    className="w-full bg-[hsl(217,91%,60%)] hover:bg-[hsl(217,91%,50%)] text-white py-3 font-semibold transition-all"
                  >
                    {contactMutation.isPending ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
          
          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <Card className="bg-[hsl(210,40%,8%)]/50 border-[hsl(217,32%,17%)]">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold mb-6 text-[hsl(217,91%,60%)]">Contact Info</h3>
                <div className="space-y-4">
                  {contactInfo.map((info, index) => (
                    <motion.div
                      key={info.title}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1, duration: 0.5 }}
                      className="flex items-center gap-4"
                    >
                      <div className={`w-12 h-12 ${info.bgColor} rounded-lg flex items-center justify-center`}>
                        {info.icon}
                      </div>
                      <div>
                        <p className="text-[hsl(215,20%,65%)]">{info.title}</p>
                        <p className="text-white font-semibold">{info.value}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
