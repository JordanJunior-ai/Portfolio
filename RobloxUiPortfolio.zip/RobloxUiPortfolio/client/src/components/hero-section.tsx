import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Gamepad2, ChevronDown } from "lucide-react";

export default function HeroSection() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-4 -left-4 w-72 h-72 bg-[hsl(217,91%,60%)]/10 rounded-full blur-3xl floating-animation"></div>
        <div className="absolute -top-8 -right-8 w-96 h-96 bg-[hsl(158,64%,52%)]/10 rounded-full blur-3xl floating-animation"></div>
        <div className="absolute -bottom-8 -left-8 w-80 h-80 bg-[hsl(256,70%,67%)]/10 rounded-full blur-3xl floating-animation"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center fade-in"
        >
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="mb-8"
          >
            <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-[hsl(217,91%,60%)] to-[hsl(158,64%,52%)] p-1">
              <div className="w-full h-full rounded-full bg-[hsl(210,40%,8%)] flex items-center justify-center">
                <Gamepad2 className="text-4xl text-[hsl(217,91%,60%)]" />
              </div>
            </div>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-5xl md:text-7xl font-bold mb-6 gradient-text"
          >
            Kirin
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="text-xl md:text-2xl text-[hsl(215,20%,65%)] mb-8"
          >
            Roblox UI Designer • 4+ Years Experience
          </motion.p>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="text-lg text-[hsl(215,20%,65%)] max-w-2xl mx-auto mb-12 leading-relaxed"
          >
            Crafting smooth, interactive UIs that make the gaming experience pop. From custom menus and buttons to slick in-game interfaces.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Button
              size="lg"
              onClick={() => scrollToSection("#portfolio")}
              className="bg-[hsl(217,91%,60%)] hover:bg-[hsl(217,91%,50%)] text-white px-8 py-6 text-lg font-semibold transition-all transform hover:scale-105"
            >
              View My Work
            </Button>
            <Button
              variant="outline"
              size="lg"
              onClick={() => scrollToSection("#contact")}
              className="border-[hsl(217,91%,60%)] text-[hsl(217,91%,60%)] hover:bg-[hsl(217,91%,60%)] hover:text-white px-8 py-6 text-lg font-semibold transition-all"
            >
              Get In Touch
            </Button>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce"
      >
        <ChevronDown className="text-[hsl(217,91%,60%)] text-xl" />
      </motion.div>
    </section>
  );
}
