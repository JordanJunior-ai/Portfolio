import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Palette, UserCog, Gamepad2, Code, Wand2, Rocket } from "lucide-react";

export default function SkillsSection() {
  const skills = [
    {
      title: "UI Design",
      description: "Expert in creating visually appealing and user-friendly interfaces for gaming environments.",
      icon: <Palette className="text-[hsl(217,91%,60%)] text-xl" />,
      progress: 95,
      color: "hsl(217,91%,60%)",
    },
    {
      title: "UX Design",
      description: "Crafting intuitive user experiences that enhance player engagement and satisfaction.",
      icon: <UserCog className="text-[hsl(158,64%,52%)] text-xl" />,
      progress: 90,
      color: "hsl(158,64%,52%)",
    },
    {
      title: "Roblox Studio",
      description: "Advanced proficiency in Roblox Studio for implementing and testing UI designs.",
      icon: <Gamepad2 className="text-[hsl(0,84%,60%)] text-xl" />,
      progress: 92,
      color: "hsl(0,84%,60%)",
    },
    {
      title: "Lua Scripting",
      description: "Skilled in Lua scripting for interactive UI elements and functionality.",
      icon: <Code className="text-[hsl(256,70%,67%)] text-xl" />,
      progress: 85,
      color: "hsl(256,70%,67%)",
    },
    {
      title: "UI Animation",
      description: "Creating smooth transitions and engaging animations for enhanced user experience.",
      icon: <Wand2 className="text-[hsl(43,89%,48%)] text-xl" />,
      progress: 88,
      color: "hsl(43,89%,48%)",
    },
    {
      title: "Performance",
      description: "Optimizing UI performance for smooth gameplay across all devices.",
      icon: <Rocket className="text-[hsl(217,91%,60%)] text-xl" />,
      progress: 87,
      color: "hsl(217,91%,60%)",
    },
  ];

  return (
    <section id="skills" className="py-20 bg-[hsl(217,32%,17%)]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[hsl(217,91%,60%)]">Skills & Expertise</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[hsl(217,91%,60%)] to-[hsl(158,64%,52%)] mx-auto"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <motion.div
              key={skill.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1, duration: 0.8 }}
              whileHover={{ scale: 1.05 }}
            >
              <Card className="bg-[hsl(210,40%,8%)]/50 border-[hsl(217,32%,17%)] hover:border-[hsl(217,91%,60%)]/50 transition-all duration-300 h-full">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-[hsl(217,91%,60%)]/20 rounded-lg flex items-center justify-center mb-4">
                    {skill.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-[hsl(217,91%,60%)]">{skill.title}</h3>
                  <p className="text-[hsl(215,20%,65%)] mb-4">{skill.description}</p>
                  <div className="w-full bg-[hsl(217,32%,17%)] rounded-full h-2 mb-2">
                    <motion.div
                      className="h-2 rounded-full"
                      style={{ backgroundColor: skill.color }}
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.progress}%` }}
                      transition={{ duration: 1, delay: 0.5 }}
                    />
                  </div>
                  <div className="text-right text-sm text-[hsl(215,20%,65%)]">
                    {skill.progress}%
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
