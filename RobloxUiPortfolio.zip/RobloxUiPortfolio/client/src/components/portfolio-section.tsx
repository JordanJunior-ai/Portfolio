import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sword, ShoppingCart, Mountain, CheckSquare } from "lucide-react";
import bladeShopImage from "@assets/image_1752693408910.png";
import shopInterfaceImage from "@assets/image_1752693414344.png";
import serenityWelcomeImage from "@assets/image_1752693417222.png";
import questManagementImage from "@assets/image_1752693435411.png";

export default function PortfolioSection() {
  const portfolioItems = [
    {
      title: "Blade Shop Interface",
      description: "A comprehensive shop system with rarity-based color coding and intuitive purchase flows for different weapon tiers.",
      icon: <Sword className="text-4xl text-white" />,
      image: bladeShopImage,
      tags: ["Shop System", "Inventory", "Rarity System"],
      tagColors: ["hsl(217,91%,60%)", "hsl(158,64%,52%)", "hsl(256,70%,67%)"],
      project: "Da Hood Remake",
    },
    {
      title: "Multi-Category Shop",
      description: "Flexible shop layout supporting various item categories with dynamic grid sizing and purchase buttons.",
      icon: <ShoppingCart className="text-4xl text-white" />,
      image: shopInterfaceImage,
      tags: ["E-commerce", "Grid Layout", "Categories"],
      tagColors: ["hsl(217,91%,60%)", "hsl(43,89%,48%)", "hsl(0,84%,60%)"],
      project: "Miami Remastered",
    },
    {
      title: "Serenity Welcome Screen",
      description: "Immersive welcome interface with atmospheric design and intuitive navigation tabs for game modes.",
      icon: <Mountain className="text-4xl text-white" />,
      image: serenityWelcomeImage,
      tags: ["Welcome Screen", "Navigation", "Atmosphere"],
      tagColors: ["hsl(217,91%,60%)", "hsl(158,64%,52%)", "hsl(256,70%,67%)"],
      project: "Serenity",
    },
    {
      title: "Quest Management UI",
      description: "Dynamic quest system with progress tracking, skip options, and reward claiming functionality.",
      icon: <CheckSquare className="text-4xl text-white" />,
      image: questManagementImage,
      tags: ["Quest System", "Progress", "Rewards"],
      tagColors: ["hsl(217,91%,60%)", "hsl(158,64%,52%)", "hsl(43,89%,48%)"],
      project: "Da Bronx",
    },
  ];

  return (
    <section id="portfolio" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[hsl(217,91%,60%)]">Portfolio</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[hsl(217,91%,60%)] to-[hsl(158,64%,52%)] mx-auto mb-4"></div>
          <p className="text-lg text-[hsl(215,20%,65%)]">A showcase of my best Roblox UI designs</p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {portfolioItems.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              whileHover={{ scale: 1.02 }}
              className="group"
            >
              <Card className="bg-[hsl(210,40%,8%)]/50 border-[hsl(217,32%,17%)] hover:border-[hsl(217,91%,60%)]/50 transition-all duration-300 overflow-hidden">
                <div className="relative overflow-hidden">
                  <div className="relative">
                    <img 
                      src={item.image} 
                      alt={item.title} 
                      className="w-full h-64 object-cover"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-all"></div>
                    <div className="absolute top-4 right-4">
                      <div className="bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                        {item.project}
                      </div>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-[hsl(217,91%,60%)]">{item.title}</h3>
                  <p className="text-[hsl(215,20%,65%)] mb-4">{item.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {item.tags.map((tag, tagIndex) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="text-sm"
                        style={{ 
                          backgroundColor: `${item.tagColors[tagIndex]}/20`,
                          color: item.tagColors[tagIndex],
                          border: `1px solid ${item.tagColors[tagIndex]}/30`
                        }}
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
