import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";

export default function Footer() {
  const socialLinks = [
    { icon: <MessageCircle className="text-xl" />, href: "#", label: "Discord" },
  ];

  return (
    <footer className="bg-[hsl(210,40%,8%)]/50 border-t border-[hsl(217,32%,17%)] py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <motion.h3 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-2xl font-bold text-[hsl(217,91%,60%)] mb-4"
          >
            Kirin
          </motion.h3>
          
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-[hsl(215,20%,65%)] mb-6"
          >
            Creating exceptional UI experiences for the Roblox community
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex justify-center gap-6 mb-8"
          >
            {socialLinks.map((link, index) => (
              <motion.a
                key={link.label}
                href={link.href}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                whileHover={{ scale: 1.2, rotate: 5 }}
                className="text-[hsl(215,20%,65%)] hover:text-[hsl(217,91%,60%)] transition-colors duration-200"
                aria-label={link.label}
              >
                {link.icon}
              </motion.a>
            ))}
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scaleX: 0 }}
            whileInView={{ opacity: 1, scaleX: 1 }}
            transition={{ delay: 1, duration: 0.8 }}
            className="border-t border-[hsl(217,32%,17%)] pt-8"
          >
            <p className="text-[hsl(215,20%,65%)]">
              &copy; 2024 Kirin. All rights reserved.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </footer>
  );
}
