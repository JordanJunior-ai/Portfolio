import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

export default function AboutSection() {
  const timelineItems = [
    {
      year: "2020-2021",
      title: "UI Designer for Da Bronx",
      description: "Developed the full UI suite for this action-packed urban game, including main menus, character customization screens, and mission tracking UI.",
      color: "hsl(217,91%,60%)",
    },
    {
      year: "2021-2022",
      title: "Lead UI Designer for Da Hood Remake",
      description: "Led the design and scripting of the new UI for the popular Da Hood remake, incorporating a more refined, streamlined interface.",
      color: "hsl(158,64%,52%)",
    },
    {
      year: "2022-2023",
      title: "Senior UI Designer for South London 2",
      description: "Designed interactive UIs for an immersive open-world game based in South London, including mission trackers, mini-maps, and event notifications.",
      color: "hsl(256,70%,67%)",
    },
    {
      year: "2023-Present",
      title: "UI Designer for Miami Remastered",
      description: "Spearheaded the redesign of the UI for this fast-paced, open-world game set in a vibrant Miami environment.",
      color: "hsl(43,89%,48%)",
    },
  ];

  return (
    <section id="about" className="py-20 bg-[hsl(217,32%,17%)]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6 text-[hsl(217,91%,60%)]">About Me</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-[hsl(217,91%,60%)] to-[hsl(158,64%,52%)] mx-auto"></div>
        </motion.div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="slide-up"
          >
            <img 
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Modern UI design workspace with multiple monitors" 
              className="rounded-xl shadow-2xl w-full h-auto"
            />
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-6 slide-up"
          >
            <p className="text-lg text-[hsl(215,20%,65%)] leading-relaxed">
              I've been diving deep into Roblox UI design for almost 6 years, crafting smooth, interactive UIs that make the gaming experience pop. From custom menus and buttons to slick in-game interfaces, I bring functionality and style together to create interfaces that players love to use.
            </p>
            
            <Card className="bg-[hsl(210,40%,8%)]/50 border-[hsl(217,32%,17%)]">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4 text-[hsl(217,91%,60%)]">Experience Timeline</h3>
                <div className="space-y-4">
                  {timelineItems.map((item, index) => (
                    <motion.div
                      key={item.year}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.2, duration: 0.5 }}
                      className="flex flex-col gap-2"
                    >
                      <div className="flex items-center gap-3">
                        <div 
                          className="w-3 h-3 rounded-full flex-shrink-0" 
                          style={{ backgroundColor: item.color }}
                        ></div>
                        <span className="text-[hsl(215,20%,65%)]">
                          <span className="font-semibold text-white">{item.year}</span> - {item.title}
                        </span>
                      </div>
                      <p className="text-sm text-[hsl(215,20%,65%)] ml-6 leading-relaxed">
                        {item.description}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
